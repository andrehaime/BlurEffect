for i in $(seq 1 10)
do 
  $1 $i 100
done 
